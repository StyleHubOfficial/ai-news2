import { defineConfig, loadEnv } from 'vite';
import react from '@vitejs/plugin-react';

// https://vitejs.dev/config/
export default defineConfig(({ mode }) => {
  // Load env file based on `mode` in the current working directory.
  const env = loadEnv(mode, (process as any).cwd(), '');
  
  return {
    plugins: [react()],
    // CRITICAL: base: './' ensures assets use relative paths, preventing 404 errors on GitHub Pages.
    base: './', 
    define: {
      // Polyfill process.env.API_KEY so the existing code continues to work after build
      // This works for both local .env files and GitHub Actions Secrets
      'process.env.API_KEY': JSON.stringify(env.API_KEY || process.env.API_KEY),
    },
    build: {
      outDir: 'dist',
    }
  };
});